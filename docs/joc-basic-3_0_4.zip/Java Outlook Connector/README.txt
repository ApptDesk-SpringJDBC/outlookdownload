Moyosoft - Java Outlook Connector - README
------------------------------------------

1. INTRODUCTION
---------------

Java Outlook Connector (JOC) is an intuitive and easy to use Java library built to
access the MS Outlook application.

Java Outlook Connector requires Microsoft Outlook 2000, 2002, 2003, XP, 2007, 2010 or 2013
and Java 1.4 or later.


2. GETTING STARTED
------------------

First, download the Java Outlook Connector Evaluation version. Then:

  I. Run the Java Outlook Connector demo applications.
  II. Take a look at the example source code.
  III. Read the Java documentation (JavaDoc) for further details.


3. USE JAVA OUTLOOK CONNECTOR
-----------------------------

To use JOC in your application:

  I. Place the JAR files (lib/joc-v3.0.4.jar and lib/moyocore.jar) in your's application CLASSPATH.
  II. Place the DLL file (lib/moyocore.dll) in java.library.path.

You can set the CLASSPATH and the java.library.path when you launch your application, e.g:

  > java -Djava.library.path=./lib -cp lib\moyocore.jar;lib\joc-v3.0.4.jar <YourClass>


4. WEBSITE AND ONLINE DOCUMENTATION
-----------------------------------

JOC Website: http://www.moyosoft.com/joc/
JOC Online documentation: http://www.moyosoft.com/joc/doc/
