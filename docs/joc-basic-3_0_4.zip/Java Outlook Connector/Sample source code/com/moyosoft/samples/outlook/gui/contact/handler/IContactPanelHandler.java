package com.moyosoft.samples.outlook.gui.contact.handler;

public interface IContactPanelHandler
{
   public void closePressed();
   public void saveAndClosePressed();
   public void deletePressed();
}
